package com.shubhamAcademy.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopingmangmentsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
