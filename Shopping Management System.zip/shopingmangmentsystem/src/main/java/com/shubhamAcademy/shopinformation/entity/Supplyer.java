package com.shubhamAcademy.shopinformation.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Supplyer {
	private int idsupplyer;
	private String supplyername;
	private String supplyerproduct;
	private String supplyerquntity;
	private String supplyerproductprice;
	private String supplyerdate;
	
	
	
	@Id
	public int getIdsupplyer() {
		return idsupplyer;
	}
	public void setIdsupplyer(int idsupplyer) {
		this.idsupplyer = idsupplyer;
	}
	public String getSupplyername() {
		return supplyername;
	}
	public void setSupplyername(String supplyername) {
		this.supplyername = supplyername;
	}
	public String getSupplyerproduct() {
		return supplyerproduct;
	}
	public void setSupplyerproduct(String supplyerproduct) {
		this.supplyerproduct = supplyerproduct;
	}
	public String getSupplyerquntity() {
		return supplyerquntity;
	}
	public void setSupplyerquntity(String supplyerquntity) {
		this.supplyerquntity = supplyerquntity;
	}
	
	public String getSupplyerproductprice() {
		return supplyerproductprice;
	}
	public void setSupplyerproductprice(String supplyerproductprice) {
		this.supplyerproductprice = supplyerproductprice;
	}
	public String getSupplyerdate() {
		return supplyerdate;
	}
	public void setSupplyerdate(String supplyerdate) {
		this.supplyerdate = supplyerdate;
	}
	@Override
	public String toString() {
		return "Supplyer [idsupplyer=" + idsupplyer + ", supplyername=" + supplyername + ", supplyerproduct="
				+ supplyerproduct + ", supplyerquntity=" + supplyerquntity + ", supplyerproductprice="
				+ supplyerproductprice + ", supplyerdate=" + supplyerdate + "]";
	}
}