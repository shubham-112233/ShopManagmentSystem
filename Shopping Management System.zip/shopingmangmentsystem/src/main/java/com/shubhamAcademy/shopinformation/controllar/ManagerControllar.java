package com.shubhamAcademy.shopinformation.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shubhamAcademy.shopinformation.entity.Customer;
import com.shubhamAcademy.shopinformation.entity.Manager;
import com.shubhamAcademy.shopinformation.service.ManagerService;

@RestController
//@RequestMapping()
public class ManagerControllar {

	@Autowired
	private ManagerService ms;

	@GetMapping("allmanager")
	public List<Manager> getmanagerdetails() {
		List<Manager> list = ms.getmanagerdetails();
System.out.println("in method");
		return list;

	}

	@PostMapping("insertmanagerdetails")
	public String getallinsertmanager(@RequestBody Manager manager) {
		return ms.getallinsertmanager(manager);

	}

	@PutMapping("updatedmanager")
	public String getupdatemanager(@RequestBody Manager manager) {

		return ms.getupdatemanager(manager);

	}

	@DeleteMapping("managerdatilsdeleted")
	public Object getdeletedmanager(@RequestBody Manager manager) {
		return ms.getdeletedmanager(manager);
	}

// to customer entity class so this method using crud operation by customer
	@PostMapping("/customers")
	public String getinsertcustomer(@RequestBody Customer customer) {
		return ms.getinsertcustomer(customer);
	}

	@GetMapping("customersdetails")
	public Object getcustumersdetails() {
		return ms.getcustomersdetails();

	}

	@PutMapping("/oldcustomers")
	public String getcustomerupdate(@RequestBody Customer customer) {
		return ms.getcustomerupdate(customer);
	}

	@GetMapping("morethank")
	public List<Manager> getmorethan20K() {
		return ms.getmorethan20K();
	}
///by using restriction class method in following code
	@GetMapping("startwiths")
	public List<Manager> getstartwithS() {
		return ms.getstarwithS();

	}
@GetMapping("starandage")
	public List<Manager> getthesemanagerprinttostartwithage30plusandsalarygreterthan56plus() {
		return ms.getthesemanagerprinttostartwithage30plusandsalarygreterthan56plus();

	}
@GetMapping("lessthanage15manger")
public List<Manager> getmanagerdetialsthoseagelessthan15() {
	return ms.getmanagerdetailsthoseagelessthan15();
}
@GetMapping("managersalarybetween30to40k")
public List<Manager> getsalarybetween3okto60k() {
	return ms.getsalarybetween3okto60k();
}

}
