package com.shubhamAcademy.shopinformation.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Manager {
	
	private int mnagerid;
	private String managername;
	private String managersalary;
	private String managerbranch;
	private String managermobno;
	private String managerage;
	private String managerbg;
	@Id
	public int getMnagerid() {
		return mnagerid;
	}
	public void setMnagerid(int mnagerid) {
		this.mnagerid = mnagerid;
	}
	public String getManagername() {
		return managername;
	}
	public void setManagername(String managername) {
		this.managername = managername;
	}
	public String getManagersalary() {
		return managersalary;
	}
	public void setManagersalary(String managersalary) {
		this.managersalary = managersalary;
	}
	public String getManagerbranch() {
		return managerbranch;
	}
	public void setManagerbranch(String managerbranch) {
		this.managerbranch = managerbranch;
	}
	public String getManagermobno() {
		return managermobno;
	}
	public void setManagermobno(String managermobno) {
		this.managermobno = managermobno;
	}
	public String getManagerage() {
		return managerage;
	}
	public void setManagerage(String managerage) {
		this.managerage = managerage;
	}
	public String getManagerbg() {
		return managerbg;
	}
	public void setManagerbg(String managerbg) {
		this.managerbg = managerbg;
	}
	@Override
	public String toString() {
		return "Manager [mnagerid=" + mnagerid + ", managername=" + managername + ", managersalary=" + managersalary
				+ ", managerbranch=" + managerbranch + ", managermobno=" + managermobno + ", managerage=" + managerage
				+ ", managerbg=" + managerbg + "]";
	}
}

	
	
	