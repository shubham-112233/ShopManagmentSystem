package com.shubhamAcademy.shopinformation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shubhamAcademy.shopinformation.dao.CustomerDao;
import com.shubhamAcademy.shopinformation.entity.Customer;
@Service
public class CustomerService {
	@Autowired
        CustomerDao cd;

	public List<Customer> getallcustomers() {
		return cd.getallcustomers();
		
		
	}

	public String getaddcustomer(Customer customer) {
	return	cd.getaddcustomer(customer);
		
	}

	public void getupdatecustomer(Customer customer) {
		cd.getupdatecustomer(customer);
		
	}

	public String getdeletecustomer(Customer customer) {
		return cd.getdeletecustomer(customer);
		
	}

	public List<Customer> getcbilldiscount15to24() {
    return   cd.getcbilldiscount15to24();
		
	}

	public List<Customer> getcustomerdate18to24() {
		return cd. getcustomerdate18to24();
		
	}

	public List<Customer> getgretterthan23Kbillamount() {
		return cd.getgretterthan23Kbillamount();
		
	}

	public List<Customer> getlessthan23k() {
		return cd.getlessthan23k();
		
	}

	public List<Customer> maxbillamount() {
		return cd.maxbillamount();
		 
	}

	public List<Customer> getminbillamount() {
	return cd.getminbillamount();
		
	}

	public List<Customer> getavg() {
		return cd.getavg();
		
		
	}

	public List<Customer> getcountcustomer() {
		return cd.gecountcustomer();
		
	}

	public List<Customer> getavgcustomer() {
	return cd.getavgcustomer();
		
	}

	public List<Customer> getcustomerdisscount() {
	return cd.getcustomerdisscount();
		
	}

	public List<Customer> getcustomerid() {
   return cd. getcustomerid();
		
	}

	public List<Customer> getrowcountcustomer() {
		return cd.getrowcountcustomer();
		
	}

	public List<Customer> getcustmercountall() {
return cd.getcustmercountall();
		
	}

	public List<Customer>  getcustomerpropertyname(){
		return cd.getcustomerpropertyname();
		
	
	}

	public List<Customer> getdistinctcount() {
		return cd. getdistinctcount();
	}

	public List<Customer> getsumname() {
	return cd.getsumname();
		
	}
	

}
