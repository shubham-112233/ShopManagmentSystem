package com.shubhamAcademy.shopinformation.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Customer {
	
private int cid;
private String cname;
private String cdate;
private String cbillamount;
private String cdisscount;
@Id
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCdate() {
	return cdate;
}
public void setCdate(String cdate) {
	this.cdate = cdate;
}
public String getCbillamount() {
	return cbillamount;
}
public void setCbillamount(String cbillamount) {
	this.cbillamount = cbillamount;
}
public String getCdisscount() {
	return cdisscount;
}
public void setCdisscount(String cdisscount) {
	this.cdisscount = cdisscount;
}
@Override
public String toString() {
	return "Customer [cid=" + cid + ", cname=" + cname + ", cdate=" + cdate + ", cbillamount=" + cbillamount
			+ ", cdisscount=" + cdisscount + "]";
}



}



