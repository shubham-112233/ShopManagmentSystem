package com.shubhamAcademy.shopinformation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.shubhamAcademy.shopinformation.dao.ManagerDao;
import com.shubhamAcademy.shopinformation.entity.Customer;
import com.shubhamAcademy.shopinformation.entity.Manager;

@Service

public class ManagerService {
	
	
	
	@Autowired
private ManagerDao dao;
	public List<Manager> getmanagerdetails() {
	return dao.getmanagerdetails();
		
	}
	//@Autowired
	public String getallinsertmanager(Manager manager) {
		return dao.getallinsertmanager(manager);
		
	}
	
	public String getupdatemanager(Manager manager) {
	    return dao.getupdatemanager( manager);
	    
		
	}
	public Object getdeletedmanager(Manager manager) {
		return dao.getdeletedmanager(manager);
		
	}
		
		
	public String getinsertcustomer(Customer customer) {
		
		return dao.getinsertcustomer(customer);
	}
	public Object getcustomersdetails() {
		return dao.getcustomersdetails();
		
	}
	public String getcustomerupdate(Customer customer) {
		return dao.getcustomerupdate(customer);
		
	}
	public List<Manager> getmorethan20K() {
     return dao.getmorethan20K();
	}
	public List<Manager> getstarwithS() {
		return dao.getstartwithS();
		
	}
	public List<Manager> getthesemanagerprinttostartwithage30plusandsalarygreterthan56plus() {
		List<Manager>list=dao.getthesemanagerprinttostartwithage30plusandsalarygreterthan56plus();
		List<Manager>al=new ArrayList<>();
		for (Manager manager : list) {
			if(Integer.parseInt(manager.getManagersalary())> Integer.parseInt("1000") && manager.getManagerage().equals("32")) {
				al.add(manager);
			}else {
			return null;
		}
	}
	return al;
	}
	public List<Manager> getmanagerdetailsthoseagelessthan15() {

		 return dao.getmanagerdetailsthoseagelessthan15();
		
		
	}
	public List<Manager> getsalarybetween3okto60k() {
		return dao.getsalarybetween3okto60k();
	}
}
