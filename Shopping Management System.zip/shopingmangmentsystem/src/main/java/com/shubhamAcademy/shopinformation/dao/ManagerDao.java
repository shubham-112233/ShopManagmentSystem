package com.shubhamAcademy.shopinformation.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shubhamAcademy.shopinformation.entity.Customer;
import com.shubhamAcademy.shopinformation.entity.Manager;

@Repository
public class ManagerDao {
	@Autowired
	SessionFactory sf;

	public List<Manager> getmanagerdetails() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Manager.class);
		List<Manager> list = criteria.list();

		return list;

	}

//	@Autowired
	public String getallinsertmanager(Manager manager) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(manager);
		tr.commit();
		return "manager Details insert successfully";
	}

	public String getupdatemanager(Manager manager) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.saveOrUpdate(manager);
		tr.commit();
		return "manager Details updatd successfully......!!!!";
	}

	public Object getdeletedmanager(Manager manager) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.load(manager, 1);
		tr.commit();
		return "deletd record successfully";
	}

	/// to write a code to crud oeration bt customer entity
	public String getinsertcustomer(Customer customer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(customer);
		tr.commit();
		return "Data store successfully";
	}

	public Object getcustomersdetails() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Customer.class);
		List<Manager> list = criteria.list();
		return list;
	}

	public String getcustomerupdate(Customer customer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.saveOrUpdate(customer);
		tr.commit();
		return "manager Details updatd successfully......!!!!";
	}

	public List<Manager> getmorethan20K() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Manager.class);
		criteria.add(Restrictions.gt("managersalary", "35000"));
		List<Manager> list = criteria.list();
		for (Manager manager : list) {
			System.out.println(manager);

		}
		return list;
	}

	public List<Manager> getstartwithS() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Manager.class);
		criteria.add(Restrictions.like("managerbg", "s%"));
		List<Manager> list = criteria.list();
		for (Manager manager : list) {
			System.out.println(manager);
		}
		return list;

	}

	public List<Manager> getthesemanagerprinttostartwithage30plusandsalarygreterthan56plus() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Manager.class);
		criteria.add(Restrictions.like("managersalary", "1000"));
		List<Manager> list = criteria.list();
		System.out.println(list);

		return list;
	}

	public List<Manager> getmanagerdetailsthoseagelessthan15() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Manager.class);
		criteria.add(Restrictions.or(Restrictions.gt("managerage", "15"), Restrictions.eq("managername", "shubham")));
		List<Manager> list = criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Manager> getsalarybetween3okto60k() {
		Session session=sf.openSession();
	Criteria criteria=	session.createCriteria(Manager.class);
	criteria.add(Restrictions.between("managersalary", "5600", "67000"));
	List<Manager>list=criteria.list();
	for (Manager manager : list) {
		System.out.println(manager);
		
	}
		return list;
		
	}

}
