package com.shubhamAcademy.shopinformation.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Staff {
	
	private int staffid;
	private String staffname;
	private String staffage;
	private String staffsalary;
	private String staffmobno;
	@Id
	public int getStaffid() {
		return staffid;
	}
	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}
	public String getStaffname() {
		return staffname;
	}
	public void setStaffname(String staffname) {
		this.staffname = staffname;
	}
	public String getStaffage() {
		return staffage;
	}
	public void setStaffage(String staffage) {
		this.staffage = staffage;
	}
	public String getStaffsalary() {
		return staffsalary;
	}
	public void setStaffsalary(String staffsalary) {
		this.staffsalary = staffsalary;
	}
	public String getStaffmobno() {
		return staffmobno;
	}
	public void setStaffmobno(String staffmobno) {
		this.staffmobno = staffmobno;
	}
	@Override
	public String toString() {
		return "Staff [staffid=" + staffid + ", staffname=" + staffname + ", staffage=" + staffage + ", staffsalary="
				+ staffsalary + ", staffmobno=" + staffmobno + "]";
	}
	

}



