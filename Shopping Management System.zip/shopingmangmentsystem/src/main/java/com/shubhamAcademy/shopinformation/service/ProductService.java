package com.shubhamAcademy.shopinformation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shubhamAcademy.shopinformation.dao.ProductDao;
import com.shubhamAcademy.shopinformation.entity.Product;

@Service
public class ProductService {
	@Autowired
	ProductDao pd;

	public List<Product> getallproductaboutshop() {
		return pd.getallproductaboutshop();

	}

	public List<Product>  insertproductnew(Product product)  {
		return pd. insertproductnew(product) ;
		
	}

	public List<Product> getupdatenewproductnameprice(Product product) {
	return pd.getupdatenewproductnameprice(product) ;
		
	}

	public Object getdeleteproductexp(Product product) {
		return pd.getdeleteproductexp(product);
		
	}

	public List<Product> getbetweenproductprice() {
		return pd.getbetweenproductprice();
		
	}

	public List<Product> getalllikeprodectsugar() {
		return pd.getalllikeprodectsugar();
		
	}

	public List<Product> getallilikeproduct() {
		return pd.getallilikeproduct();
		
	}

	public List<Product> getmorethan34() {
	return pd.getmorethan34();
		
	}

	public List<Product> getlessthanproductprice() {
	return pd.getlessthanproductprice();
		
	}

	public List<Product> getgretterthanprice() {
     return pd.getgretterthanprice() ;
		
	}

	public List<Product> getlessthanpriceproduct() {
	return pd. getlessthanpriceproduct();
		
	}

	public List<Product> getallproductavilable() {
		return pd.getallproductavilable();
		
	}

	public List<Product> getminprice() {
		return pd.getminprice();
		
	}

	public List<Product> getmaxprice() {
		return pd.getmaxprice();
	}

	public List<Product> getproductavg() {
	return pd.getproductavg();
		
	}

	public List<Product> getrowcount() {
		return pd. getrowcount() ;
		
	}

	public List<Product> getidprodut() {
		return pd. getidprodut();
		
	}

	public List<Product> getdistinctcountproduct() {
		return pd.getdistinctcountproduct();
		// TODO Auto-generated method stub
		
	}

	public List<Product> getsumpriceofproductprice() {
		return pd.getsumpriceofproductprice();
		
	}

	public List<Product> getproductproperty() {
		return pd.getproductproperty();
		
	}

}
