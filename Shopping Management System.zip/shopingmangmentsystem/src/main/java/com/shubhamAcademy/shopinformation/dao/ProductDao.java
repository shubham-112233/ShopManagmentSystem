package com.shubhamAcademy.shopinformation.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shubhamAcademy.shopinformation.entity.Customer;
import com.shubhamAcademy.shopinformation.entity.Product;

@Repository
public class ProductDao {
	@Autowired
	SessionFactory sf;

	public List<Product> getallproductaboutshop() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		List<Product> list = criteria.list();
		return list;

	}

	public List<Product> insertproductnew(Product product) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Product.class);
		session.save(product);
		tr.commit();
		List<Product> list = criteria.list();
		return list;

	}

	public List<Product> getupdatenewproductnameprice(Product product) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Product.class);
		session.saveOrUpdate(product);
		tr.commit();
		List<Product> list = criteria.list();
		return list;
	}

	public List<Product> getdeleteproductexp(Product product) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Product.class);
		session.delete(product);
		tr.commit();
		List<Product> list = criteria.list();
		return list;
	}

	public List<Product> getbetweenproductprice() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.between("price", "10", "70"));
		List<Product> list = criteria.list();
		System.out.println(list);
		return list;

	}

	public List<Product> getalllikeprodectsugar() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.like("name", "s%"));
		List<Product> list = criteria.list();
		System.out.println(list);
		return list;

	}

	public List<Product> getallilikeproduct() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.ilike("name", "A%"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
		

	}

	public List<Product> getmorethan34() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.ge("price", "34"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getlessthanproductprice() {
	
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.le("price", "34"));
		List<Product>list=criteria.list();
	return list;
	}

	public List<Product> getgretterthanprice() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.gt("price", "70"));
	List<Product>list=criteria.list();
	System.out.println(list);
	return list;
	}

	public List<Product> getlessthanpriceproduct() { 
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.lt("price", "70"));
	List<Product>list=criteria.list();
	
	return list;
	}

	public List<Product> getallproductavilable() {
	
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.count("name"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getminprice() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.min("price"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getmaxprice() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.max("price"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getproductavg() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.avg("disscount"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
		
	}

	public List<Product> getrowcount() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.rowCount());
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
		
		
	}

	public List<Product> getidprodut() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.id());
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getdistinctcountproduct() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.countDistinct("date"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getsumpriceofproductprice() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.sum("price"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Product> getproductproperty() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.setProjection(Projections.property("name"));
		List<Product>list=criteria.list();
		System.out.println(list);
		return list;
		
	}
		
	}
		
	
		
	
	

