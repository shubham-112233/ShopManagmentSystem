package com.shubhamAcademy.shopinformation.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shubhamAcademy.shopinformation.entity.Supplyer;
import com.shubhamAcademy.shopinformation.service.SupplyerService;

@RestController
public class SupplyerControllar {

	@Autowired
	private SupplyerService ss;

	@GetMapping("allthesupplyershop")
	public List<Supplyer> getall() {
		return ss.getallsupplyer();
	}

	@PostMapping("supplyernew")
	public String getaddnewsupplyer(@RequestBody Supplyer supplyer) {
		return ss.getaddnewsupplyer(supplyer);
	}

	@DeleteMapping("supplyer remove")
	public String getdeletesupplyeroldnameorcompanyorproduct(@RequestBody Supplyer supplyer) {
		return ss.getdeletesupplyeroldnameorcompanyorproduct(supplyer);
	}

	@PutMapping("newupdateproductname")
	public String getupdatesupplyerdetails(@PathVariable Supplyer supplyer) {
		return ss.getupdatesuuplyerdetails(supplyer);
	}

	@GetMapping("dates of supplyer")
	public List<Supplyer> getmorethandatesupplyer() {
		return ss.getmorethandatesupplyer();
	}

	// these supplyer print 30 quntitity is gretter
	@GetMapping("allthesupplyerquntitymorethan30")
	public List<Supplyer> getsupplyerproductquntitymorethan30() {
		return ss.getsupplyerproductquntitymorethan30();
	}

	// these supplyer print these quntityis 30 or 30 plus supplyer print
	@GetMapping("these supplyer supply product only 30")
	public List<Supplyer> getthesesupplyerprintthessupplyerquntityonly30() {
		return ss.getthesesupplyerprintthessupplyerquntityonly30();
	}

	@GetMapping("these supplyer product price lessthan 30")
	public List<Supplyer> getsupplyerlessproductpricesalt() {
		return ss.getsupplyerlessproductpricesalt();
	}

	@GetMapping("these supplyer product name detergent wash")
	public List<Supplyer> getthesesupplyersupplydetergentwashthesename() {
		return ss.getthesesupplyersupplydetergentwashthesename();
	}
	@GetMapping("likesupplyername")
	public List<Supplyer> getsupplyerproductnamelike() {
		return ss. getsupplyerproductnamelike();
	}
	@GetMapping("ilikesupplyername")
	public List<Supplyer> getilikesupplyername() {
		return ss.getilikesupplyername();
	}
	@GetMapping("printthesupplyerproductpricemax")
	public List<Supplyer> getmaxsupplyernameprice() {
		return ss.getmaxsupplyernameprice() ;
	}
	@GetMapping("showthesesuplyersupplyquntitylovest ")
	public List<Supplyer> getminsupplyerproductquntity() {
		return ss.getminsupplyerproductquntity() ;
	}
	@GetMapping("show the avg of getsupplyer")
	public List<Supplyer> getsupplyeravg() {
		return ss.getsupplyeravg();
	}
	@GetMapping("show the countname")
	public List<Supplyer> getsupplyercountname() {
		return ss.getsupplyercountname();
	}
	
	public List<Supplyer> getsupplyerproperties() {
	return	ss.getsupplyerproperties();
		
	}
}













