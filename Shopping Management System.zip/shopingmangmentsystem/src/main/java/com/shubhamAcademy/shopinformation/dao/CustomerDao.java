package com.shubhamAcademy.shopinformation.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

import com.shubhamAcademy.shopinformation.entity.Customer;

@Repository
public class CustomerDao {
	@Autowired
	SessionFactory sf;

	public List<Customer> getallcustomers() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Customer.class);
		List<Customer> list = criteria.list();
		return list;

	}

	public String getaddcustomer(Customer customer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Customer.class);
		session.save(customer);
		tr.commit();
		return "welcome to new customer";

	}

	public String getupdatecustomer(Customer customer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Customer.class);
		session.saveOrUpdate(customer);
		tr.commit();
		return "your data updated successfully";

	}

	public String getdeletecustomer(Customer customer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Customer.class);
		session.delete(customer);
		tr.commit();
		return "your customer deleted successfully";

	}
public List<Customer> getcbilldiscount15to24() {
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.add(Restrictions.between("cdisscount", "15%", "24%"));
	List<Customer>list=criteria.list();
	return list;
	
}

public List<Customer> getcustomerdate18to24() {
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.add(Restrictions.between("cdate", "18/4/2023", "28/4/2023"));
	List<Customer>list=criteria.list();
	return list;
}

public List<Customer> getgretterthan23Kbillamount() {
	Session session=sf.openSession();
Criteria criteria=	session.createCriteria(Customer.class);
criteria.add(Restrictions.ge("cbillamount", "23000"));
List<Customer>list=criteria.list();
return list;
	
	
}

public List<Customer> getlessthan23k() {
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.add(Restrictions.lt("cbillamount","23000"));
	List<Customer>list=criteria.list();
	return list;
}

public List<Customer> maxbillamount() {
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.max("cbillamount"));
	List<Customer>list=criteria.list();
	return list;
}

public List<Customer> getminbillamount() {
	Session session=sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.min("cbillamount"));
	List<Customer>list=criteria.list();
	return list;
	
}

public List<Customer> getavg() {
	Session session=sf.openSession();
Criteria criteria=	session.createCriteria(Customer.class);
criteria.setProjection(Projections.avg("cdisscount"));
List<Customer>list=criteria.list();
System.out.println(list);
return list;
}

public List<Customer> gecountcustomer() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.count("cid"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
}

public List<Customer> getavgcustomer() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.avg("cbillamount"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;

	
}

public List<Customer> getcustomerdisscount() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.sum("cbillamount"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;

	
}

public List<Customer> getcustomerid() {
	
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.id());
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
}

public List<Customer> getrowcountcustomer() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.rowCount());
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
	
}

public List<Customer> getcustmercountall() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.count("cname"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;

	
}

public List<Customer> getcustomerpropertyname() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.property("cname"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
	
}

public List<Customer> getdistinctcount() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.countDistinct("cdate"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
	
	
}

public List<Customer> getsumname() {
	Session session =sf.openSession();
	Criteria criteria=session.createCriteria(Customer.class);
	criteria.setProjection(Projections.sum("cname"));
	List<Customer>list=criteria.list();
	System.out.println(list);
	return list;
	
}
}
