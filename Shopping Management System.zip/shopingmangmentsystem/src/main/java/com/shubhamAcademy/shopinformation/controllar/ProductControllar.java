package com.shubhamAcademy.shopinformation.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shubhamAcademy.shopinformation.entity.Product;
import com.shubhamAcademy.shopinformation.service.ProductService;

@RestController
public class ProductControllar {
	@Autowired
	
	private ProductService pc;
	@GetMapping("allproductdetails")
	public List<Product> getallproductaboutshop() {
	return 	pc.getallproductaboutshop();
		
	}
	@PostMapping("addnewproduct")
	public List<Product> insertproductnew(@RequestBody Product product) {
		return pc. insertproductnew(product) ;
	}
	@PutMapping("updatenawproduct")
public List<Product> getupdatenewproductnameprice(@RequestBody Product product) {
	return pc.getupdatenewproductnameprice(product);
}
	@DeleteMapping("deleteexproduct")
public Object getdeleteproductexp(Product product) {
	return pc.getdeleteproductexp(product);
}
	@GetMapping("productpricebetwen")
public List<Product> getbetweenproductprice() {
	return pc.getbetweenproductprice();
	
	
}
	@GetMapping("productlikecustomer")
	public List<Product> getalllikeprodectsugar() {
		return pc.getalllikeprodectsugar();
		
	}
	@GetMapping("productnotselling")
	public List<Product> getallilikeproduct() {
		return pc.getallilikeproduct();
		
	}
	@GetMapping("productprice")
	public List<Product> getmorethan34() {
		return pc.getmorethan34();
	}
	@GetMapping("lessproductprice")
	public List<Product> getlessthanproductprice() {
		return pc.getlessthanproductprice();
		
	}
	@GetMapping("highestpriceproduct")
	public List<Product> getgretterthanprice() {
		return pc.getgretterthanprice() ;
	}
	@GetMapping("lessproductrice")
	public List<Product> getlessthanpriceproduct() {
		return pc.getlessthanpriceproduct();
	}
	@GetMapping("getalltheproduct")
	public List<Product> getallproductavilable() {
		return pc.getallproductavilable();
	}
	@GetMapping("getallminpriceproduct")
	public List<Product> getminprice() {
		return pc.getminprice() ;
	}
	@GetMapping("maxprice")
	public  List<Product> getmaxprice() {
		return pc.getmaxprice();
		
	}
	@GetMapping("avgofdisscountofproduct")
	public List<Product> getproductavg() {
		return pc.getproductavg();
	}
	@GetMapping("rowcountroduct")
	public List<Product> getrowcount() {
		return pc.getrowcount();
	}
	@GetMapping("countidofproduct")
	public List<Product> getidprodut() {
		return pc.getidprodut();
	}
	@GetMapping("distimctcoundateproductdate")
	public List<Product> getdistinctcountproduct() {
		return pc.getdistinctcountproduct();
	}
	@GetMapping("sumofproductprice")
	public List<Product> getsumpriceofproductprice() {
		return pc.getsumpriceofproductprice();
	}
	@GetMapping("productpropertyname")
	public List<Product> getproductproperty() {
		return pc.getproductproperty();
	}
}
