package com.shubhamAcademy.shopinformation.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shubhamAcademy.shopinformation.entity.Manager;
import com.shubhamAcademy.shopinformation.entity.Staff;
import com.shubhamAcademy.shopinformation.service.ManagerService;
import com.shubhamAcademy.shopinformation.service.StaffService;

@RestController

public class StaffControllar {
	@Autowired
	private StaffService sc;

	@GetMapping("allstaff")
	public List<Staff> getstaffdetails() {
		List<Staff> list = sc.getstaffdetails();

		return list;

	}

	@PostMapping("addstaff")
	public String getinsertstaff(@RequestBody Staff staff) {
		return sc.getinsertstaff(staff);
	}

	@PutMapping("updatestaff")
	public Object updatestaff(@RequestBody Staff staff) {
		return sc.updatestaff(staff);

	}

	@DeleteMapping("/staff/{id}")
	public String getleavestaff(@PathVariable("id") int staffid) {
		return sc.getleavestaff(staffid);
	}

	@GetMapping("all the staff age is 30plus")
	public Object getstaffagemorethan19() {
		return sc.getstaffmorethan19();
	}

	@GetMapping("all the staff age is less than 30 ")
	public List<Staff> getallthestaffisagelessthan35() {
		return sc.getallthestaffisagelessthan35();
	}

	@GetMapping("these saff salary gretter than 34k")
	public List<Staff> getthesestaffsalarymorethan34k() {
		return sc.getgetthesestaffsalarymorethan34k();
	}

	public Object getlessthansalary30K() {
		return sc.getlessthansalary30K();
	}

	@GetMapping("these staff name start with s")
	public List<Staff> getstaffnamestartwiths() {
		return sc.getstaffnamestartwiths();

	}

	@GetMapping("these staff age 19 to 35")
	public List<Staff> getthesestaffage19to40details() {
		return sc.getthesestaffage19to40details();
	}

	@GetMapping("these staff salary 17kto57k")
	public List<Staff> getthesestaffsalary17Kto56K() {
		return sc.getthesestaffsalary17Kto56K();
	}

	@GetMapping("maximum age")
	public Object getmaxageofstaff() {
		return sc.getmaxageofstaff();
	}

	@GetMapping("minimumage ")
	public List<Staff> getminimumagestaff() {
		return sc.getminimumagestaff();

	}
	@GetMapping("maxsalary")
	public List<Staff> getmaxsalary() {
		return sc.getmaxsalary();
	}
	@GetMapping("minsalary")
	public List<Staff> getminimumsalary() {
		return sc.getminimumsalary();
	}
	@GetMapping("countthestaffnameall")
	public List<Staff> getcountstaffname() {
		return sc. getcountstaffname();
	}
	@GetMapping("avgsalaryofstaff")
	public List<Staff> getavgsalaryofstaff() {
		return sc.getavgsalaryofstaff();
		
	}
}