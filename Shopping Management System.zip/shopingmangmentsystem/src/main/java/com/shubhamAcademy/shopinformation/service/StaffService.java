package com.shubhamAcademy.shopinformation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.shubhamAcademy.shopinformation.dao.ManagerDao;
import com.shubhamAcademy.shopinformation.dao.StaffDao;
import com.shubhamAcademy.shopinformation.entity.Manager;
import com.shubhamAcademy.shopinformation.entity.Staff;

@Service

public class StaffService {
	@Autowired

	private StaffDao dao;

	public List<Staff> getstaffdetails() {
		List<Staff> list = dao.getstaffdetails();

		return list;

	}

	public String getinsertstaff(Staff staff) {
		return dao.getinsertstaff(staff);

	}

	public Object updatestaff(Staff staff) {
		return dao.getuodatestaff(staff);

	}

	public String getleavestaff(int staffid) {
		return dao.getleavestaff(staffid);

	}

	public List<Staff> getstaffmorethan19() {
		return dao.getsaffmorethan19();

	}

	public List<Staff> getallthestaffisagelessthan35() {
		return dao.getallthestaffisagelessthan35();

	}

	public List<Staff> getgetthesestaffsalarymorethan34k() {
		return dao.getgetthesestaffsalarymorethan34k();

	}

	public List<Staff> getlessthansalary30K() {
		return dao.getlessthansalary30K();

	}

	public List<Staff> getstaffnamestartwiths() {
		return dao.getstaffnamestartwiths();

	}

	public List<Staff> getthesestaffage19to40details() {
		return dao.getthesestaffage19to40details();

	}

	public List<Staff> getthesestaffsalary17Kto56K() {
		return dao.getthesestaffsalary17Kto56K();

	}

	public List<Staff> getmaxageofstaff() {

		return dao.getmaxageofstaff();

	}

	public List<Staff> getminimumagestaff() {
		return dao.getminimumagestaff();
	}

	public List<Staff> getmaxsalary() {
		return dao.getmaxsalary();

	}

	public List<Staff> getminimumsalary() {
		return dao.getminimumsalary();

	}

	public List<Staff> getcountstaffname() {
	return dao.getcountstaffname() ;
		
	}

	public List<Staff> getavgsalaryofstaff() {
		return dao.getavgsalaryofstaff();
		
	}
}