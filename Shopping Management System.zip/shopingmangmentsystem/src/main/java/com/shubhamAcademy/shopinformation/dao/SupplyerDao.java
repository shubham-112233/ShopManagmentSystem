package com.shubhamAcademy.shopinformation.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shubhamAcademy.shopinformation.entity.Supplyer;

@Repository
public class SupplyerDao {
	@Autowired
	SessionFactory sf;

	public List<Supplyer> getallsupplyer() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		List<Supplyer> list = criteria.list();
		// System.out.println(list);

		return list;
	}

	public String getaddnewsupplyer(Supplyer supplyer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Supplyer.class);
		session.save(supplyer);
		tr.commit();
		return "add new supplyer sucssessfuly";

	}

	public String getdeletesupplyeroldnameorcompanyorproduct(Supplyer supplyer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Supplyer.class);
		session.load(Supplyer.class, 1);
		session.delete(supplyer);
		tr.commit();
		return "delete data successfuly";

	}

	public String getupdatesupplyerdetails(Supplyer supplyer) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Supplyer.class);
		session.saveOrUpdate(supplyer);
		tr.commit();
		return "update new supplyer";
	}

	public List<Supplyer> getmorethandatesupplyer() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.between("supplyerdate", "3/3/2023", "8/3/2023"));
		List<Supplyer> list = criteria.list();
		for (Supplyer supplyer : list) {
			System.out.println(supplyer);

		}
		return list;

	}

	public List<Supplyer> getsupplyerproductquntitymorethan30() {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.gt("supplyerquntity", "30"));
		List<Supplyer> list1 = criteria.list();
		for (Supplyer supplyer : list1) {
			System.out.println(supplyer);
		}
		return list1;
	}

	public List<Supplyer> getthesesupplyerprintthessupplyerquntityonly30() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);

		criteria.add(Restrictions.ge("supplyerquntity", "30"));
		List<Supplyer> list = criteria.list();
		for (Supplyer supplyer : list) {
			System.out.println(supplyer);
		}
		return list;
	}

	public List<Supplyer> getsupplyerlessproductpricesalt() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.le("supplyerproductprice", "30"));
		List<Supplyer> list = criteria.list();
		for (Supplyer supplyer : list) {
			System.out.println(supplyer);
		}
		return list;

	}

	public List<Supplyer> getthesesupplyersupplydetergentwashthesename() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.eq("supplyerproduct", "detergentwash"));
		List<Supplyer> list = criteria.list();
		for (Supplyer supplyer : list) {
			System.out.println(supplyer);
		}
		return list;
	}

	public List<Supplyer> getsupplyerproductnamelike() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.like("supplyername", "s%"));
		List<Supplyer> list = criteria.list();
		System.out.println(list);
		return list;
		
	}

	public List<Supplyer> getilikesupplyername() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.add(Restrictions.ilike("supplyername", "A%"));
		List<Supplyer> list = criteria.list();
		System.out.println(list);
		return list;
		
	}

	public List<Supplyer> getmaxsupplyernameprice() {
		
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.setProjection(Projections.max("supplyerproductprice"));
		List<Supplyer>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Supplyer> getminsupplyerproductquntity() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.setProjection(Projections.min("supplyerquntity"));
		List<Supplyer>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Supplyer> getsupplyeravg() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.setProjection(Projections.avg("supplyerquntity"));
		List<Supplyer>list=criteria.list();
		System.out.println(list);
		return list;
	}

	public List<Supplyer> getsupplyercountname() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.setProjection(Projections.count("supplyername"));
		List<Supplyer>list=criteria.list();
		System.out.println(list);
		return list;
	
		
	}

	public List<Supplyer> getsupplyerproperties() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Supplyer.class);
		criteria.setProjection(Projections.property("supplyername"));
		List<Supplyer>list1=criteria.list();
		System.out.println(list1);
		return list1;
		
		
		
		
	}

		
	}
	

