package com.shubhamAcademy.shopinformation.controllar;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shubhamAcademy.shopinformation.entity.Customer;
import com.shubhamAcademy.shopinformation.service.CustomerService;
@RestController
public class CustomerControllar {
	@Autowired
	private CustomerService cs;
	@GetMapping("allcustomer")
	public List<Customer> getallcustomers() {
		return cs.getallcustomers();
		
	}
	@PostMapping("allnewcustomer")
public String addcustomer(@RequestBody Customer customer) {
	return cs.getaddcustomer(customer);
}
	@PutMapping("new data of cusomer")
	public void getudatecustomer(@RequestBody Customer customer) {
		cs.getupdatecustomer(customer);
	}
	@DeleteMapping
	public String getdeletecustomer(Customer customer) {
		return cs.getdeletecustomer(customer);
	}
	@GetMapping("detilsdiscountcustomer15to24")
	public List<Customer> getcbilldiscount15to24() {
		return cs.getcbilldiscount15to24();
		
	}
	@GetMapping("customerdetilsin10days")
	public List<Customer> getcustomerdate18to24() {
		return cs.getcustomerdate18to24();
		
	}
	@GetMapping("customerbilamount23kgretterthan")
	public List<Customer> getgretterthan23Kbillamount() {
		return cs.getgretterthan23Kbillamount();
	}
	@GetMapping("customerbillamountlessthan23k")
	public List<Customer> getlessthan23k() {
		return cs. getlessthan23k();
	}
	@GetMapping("maxbillamount")
	public List<Customer> maxbillamount(){
		return cs. maxbillamount();
}
	@GetMapping("minbillamount")
	public List<Customer> getminbillamount() {
		return cs.getminbillamount();
	}
	@GetMapping("avgofcustomerdisscount")
	public List<Customer> getavg() {
		return cs.getavg();
	}
	@GetMapping("allthecustomer")
	public List<Customer> getcountcustomer() {
		return cs.getcountcustomer();
	}
	@GetMapping("allthecustomeravgcbillamount")
	
	public List<Customer> getavgcustomer() {
		return cs. getavgcustomer();
	}
	@GetMapping("allthesumdisscountsum")
	public List<Customer> getcustomerdisscount() {
		return cs.getcustomerdisscount();
	}
	@GetMapping("allcustomerid")
	public List<Customer> getcustomerid() {
		return cs .getcustomerid();
		
	}
	@GetMapping("allthecustomerrow")
	
	public List<Customer> getrowcountcustomer() {
		return cs.getrowcountcustomer();
	}
	@GetMapping("allthecustomercount")
	public void getcustmercountall() {
		cs.getcustmercountall();
	}
	@GetMapping("customerpropertyname")
	public List<Customer> getcustomerpropertyname() {
		return cs .getcustomerpropertyname();
		
	}
	@GetMapping("allcoustomerdistinctcount")
	public List<Customer> getdistinctcount() {
		return cs.getdistinctcount();
		
	}
	@GetMapping("sumthecustomername")
	public List<Customer> getsumname() {
		return cs.getsumname();
	}
}
