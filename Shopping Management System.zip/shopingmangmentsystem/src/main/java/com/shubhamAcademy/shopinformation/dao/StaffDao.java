package com.shubhamAcademy.shopinformation.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.shubhamAcademy.shopinformation.entity.Manager;
import com.shubhamAcademy.shopinformation.entity.Staff;
import com.shubhamAcademy.shopinformation.entity.Supplyer;

@Repository

public class StaffDao {
	@Autowired
	SessionFactory sf;

	public List<Staff> getstaffdetails() {

		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		List<Staff> list = criteria.list();

		return list;
	}

	public String getinsertstaff(Staff staff) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Staff.class);
		session.save(staff);
		tr.commit();
		return "inserted data successfully";

	}

	public String getuodatestaff(Staff staff) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Staff.class);
		session.update(staff);
		tr.commit();
		return "data updated successfully";

	}

	public String getleavestaff(int staffid) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria criteria = session.createCriteria(Staff.class);
		// session.load(Staff.class, 1);
		session.delete(staffid);
		tr.commit();
		return "staff deleted successfully";

	}

	public List<Staff> getsaffmorethan19() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.ge("staffage", "30"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;

	}

	public List<Staff> getallthestaffisagelessthan35() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.le("staffage", "30"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;
	}

	public List<Staff> getgetthesestaffsalarymorethan34k() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.gt("staffsalary", "34000"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;
	}

	public List<Staff> getlessthansalary30K() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.le("staffsalary", "30000"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;
	}

	public List<Staff> getstaffnamestartwiths() {

		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.like("staffnamae", "s%"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;
	}

	public List<Staff> getthesestaffage19to40details() {
		// public List<Supplyer> getmorethandatesupplyer() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.between("staffage", "19", "35"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);

		}
		return list;

	}

	public List<Staff> getthesestaffsalary17Kto56K() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.between("staffsalary", "17000", "56000"));
		List<Staff> list = criteria.list();
		for (Staff staff : list) {
			System.out.println(staff);
		}
		return list;
	}

	public List<Staff> getmaxageofstaff() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.setProjection(Projections.max("staffage"));
		List<Staff> list = criteria.list();

		System.out.println(list);

		return list;

	}

	public List<Staff> getminimumagestaff() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.setProjection(Projections.min("staffage"));
		List<Staff> list = criteria.list();
		return list;

	}

	public List<Staff> getmaxsalary() {
		Session session=sf.openSession();
	Criteria criteria=	session.createCriteria(Staff.class);
	criteria.setProjection(Projections.max("staffsalary"));
	
		List<Staff>list=criteria.list();
		return list;
	}

	public List<Staff> getminimumsalary() {
		Session session=sf.openSession();
	Criteria criteria=	session.createCriteria(Staff.class);
	criteria.setProjection(Projections.min("staffsalary"));
		List<Staff>list=criteria.list();
		return list;
	}

	public List<Staff> getcountstaffname() {
		Session session=sf.openSession();
		Criteria criteria=	session.createCriteria(Staff.class);
		criteria.setProjection(Projections.count("staffname"));
			List<Staff>list=criteria.list();
			return list;
		}

	public List<Staff> getavgsalaryofstaff() {
		Session session=sf.openSession();
		Criteria criteria=	session.createCriteria(Staff.class);
		criteria.setProjection(Projections.avg("staffsalary"));
			List<Staff>list=criteria.list();
			return list;
		}

		
	}
		
	


