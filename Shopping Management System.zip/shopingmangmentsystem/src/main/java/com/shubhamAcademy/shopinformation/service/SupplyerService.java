package com.shubhamAcademy.shopinformation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shubhamAcademy.shopinformation.dao.SupplyerDao;
import com.shubhamAcademy.shopinformation.entity.Supplyer;

@Service
public class SupplyerService {
	@Autowired
	private SupplyerDao sd;

	public List<Supplyer> getallsupplyer() {
		return sd.getallsupplyer();

	}

	public String getaddnewsupplyer(Supplyer supplyer) {
		return sd.getaddnewsupplyer(supplyer);

	}

	public String getdeletesupplyeroldnameorcompanyorproduct(Supplyer supplyer) {
		return sd.getdeletesupplyeroldnameorcompanyorproduct(supplyer);

	}

	public String getupdatesuuplyerdetails(Supplyer supplyer) {
		return sd.getupdatesupplyerdetails(supplyer);

	}

	public List<Supplyer> getmorethandatesupplyer() {
		return sd.getmorethandatesupplyer();

	}

	public List<Supplyer> getsupplyerproductquntitymorethan30() {
		return sd.getsupplyerproductquntitymorethan30();

	}

	public List<Supplyer> getthesesupplyerprintthessupplyerquntityonly30() {
		return sd.getthesesupplyerprintthessupplyerquntityonly30();

	}

	public List<Supplyer> getsupplyerlessproductpricesalt() {
		return sd.getsupplyerlessproductpricesalt();

	}

	public List<Supplyer> getthesesupplyersupplydetergentwashthesename() {
		return sd.getthesesupplyersupplydetergentwashthesename();

	}

	public List<Supplyer> getsupplyerproductnamelike() {
		return sd.getsupplyerproductnamelike();

	}

	public List<Supplyer> getilikesupplyername() {
		return sd.getilikesupplyername();

	}

	public List<Supplyer> getmaxsupplyernameprice() {
		return sd.getmaxsupplyernameprice();

	}

	public List<Supplyer> getminsupplyerproductquntity() {
		return sd.getminsupplyerproductquntity();

	}

	public List<Supplyer> getsupplyeravg() {
		return sd.getsupplyeravg();

	}

	public List<Supplyer> getsupplyercountname() {
		return sd.getsupplyercountname();

	}

	public List<Supplyer> getsupplyerproperties() {
		return sd.getsupplyerproperties();

	}

}
